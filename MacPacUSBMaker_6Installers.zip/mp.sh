#!/bin/bash

# This script was made by @ios_euphoria

echo "--- Running MacPac Flasher! ---"
yes yes | sudo bash ./macpac.sh