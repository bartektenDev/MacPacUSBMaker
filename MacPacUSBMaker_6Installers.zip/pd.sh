#!/bin/bash

# This script was made by @ios_euphoria

echo "--- Running MacPac Prep Drive! ---"
yes yes | sudo bash ./prepdrive.sh
