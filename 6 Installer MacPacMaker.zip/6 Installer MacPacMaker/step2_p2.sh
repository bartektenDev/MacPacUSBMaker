#!/bin/bash


echo "     --------------- Welcome to MacPac! ---------------     "
echo "Developed by: Bart Tarasewicz @ios_euphoria"
echo "We will first wipe disk2. Then auto-flash 6 operating systems to USB."
echo ""
echo "------ Warning! Please run step1.sh first, then this script. ------"
echo ""
echo ""

read -t 5 -p "Starting flash in 5 seconds..."

echo ""
echo "Installing Mac OS Monterey..."
sudo /Applications/Install\ macOS\ Monterey.app/Contents/Resources/createinstallmedia --volume /Volumes/MontereyInstaller|lolcat -a -d 200
echo "Mac OS Monterey Installed on USB!"

echo ""
echo "Installing Mac OS Big Sur..."
sudo /Applications/Install\ macOS\ Big\ Sur.app/Contents/Resources/createinstallmedia --volume /Volumes/BigSurInstaller|lolcat -a -d 200
echo "Mac OS Big Sur Installed on USB!"

echo ""
echo "Installing Mac OS Catalina..."
sudo /Applications/Install\ macOS\ Catalina.app/Contents/Resources/createinstallmedia --volume /Volumes/CatalinaInstaller|lolcat -a -d 200
echo "Mac OS Catalina Installed on USB!"

echo ""
echo "Installing Mac OS Mojave..."
sudo /Applications/Install\ macOS\ Mojave.app/Contents/Resources/createinstallmedia --volume /Volumes/MojaveInstaller
echo "Mac OS Mojave Installed on USB!"

echo ""
echo "Installing Mac OS High Sierra..."
sudo /Applications/Install\ macOS\ High\ Sierra.app/Contents/Resources/createinstallmedia --volume /Volumes/HighSierraInstaller|lolcat -a -d 200
echo "Mac OS High Sierra Installed on USB!"


echo ""
echo "Installing Mac OS El Capitan..."
sudo /Applications/Install\ OS\ X\ El\ Capitan.app/Contents/Resources/createinstallmedia --volume /Volumes/CapitanInstaller --applicationpath /Applications/Install\ OS\ X\ El\ Capitan.app|lolcat -a -d 200
echo "Mac OS El Capitan Installed on USB!"

echo ""
echo "------ MacPac USB Created Successfully with 6 Installers!!! ------"
echo ""
echo "Enjoy! $ $ $"
