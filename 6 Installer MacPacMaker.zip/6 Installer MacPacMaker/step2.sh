#!/bin/bash


echo "--- Running MacPac 6 Installers Flasher! ---"
yes yes | sudo bash ./step2_p2.sh
