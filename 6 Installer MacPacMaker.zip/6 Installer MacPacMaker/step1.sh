#!/bin/bash


echo "--- Running MacPac Prep Drive! ---"
yes yes | sudo bash ./step1_p2.sh
